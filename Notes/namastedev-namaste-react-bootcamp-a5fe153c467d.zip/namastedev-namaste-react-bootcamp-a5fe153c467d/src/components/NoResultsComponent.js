const NoResultsComponent = () => {
  return <h1>No Results Found!</h1>;
};
export default NoResultsComponent;
